using UnityEngine;

public class EnemyChase : MonoBehaviour
{
    public float speed = 3.0f;
    public int maxHealth = 3;
    private int currentHealth;
    private Transform playerTransform;

    // Flag to control cloning only once on the original enemy
    public bool isOriginal = true;

    void Start()
    {
        currentHealth = maxHealth;
        GameObject player = GameObject.Find("player");
        if (player != null)
        {
            playerTransform = player.transform;
        }

        if (isOriginal)
        {
            SpawnTwoEnemiesAtStart();
        }
    }

    void Update()
    {
        if (playerTransform != null)
        {
            Vector3 direction = (playerTransform.position - transform.position).normalized;
            transform.position += direction * speed * Time.deltaTime;
        }
    }

    void SpawnTwoEnemiesAtStart()
    {
        Vector3 spawnPos1 = transform.position + new Vector3(1f, 0, 1f);
        Vector3 spawnPos2 = transform.position + new Vector3(-1f, 0, -1f);

        GameObject clone1 = Instantiate(gameObject, spawnPos1, transform.rotation);
        GameObject clone2 = Instantiate(gameObject, spawnPos2, transform.rotation);

        // Mark clones as not original so they do not clone again
        clone1.GetComponent<EnemyChase>().isOriginal = false;
        clone2.GetComponent<EnemyChase>().isOriginal = false;

        // Reset their health
        clone1.GetComponent<EnemyChase>().ResetHealth();
        clone2.GetComponent<EnemyChase>().ResetHealth();
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0)
        {
            Destroy(gameObject);
        }
    }

    public void ResetHealth()
    {
        currentHealth = maxHealth;
    }
}