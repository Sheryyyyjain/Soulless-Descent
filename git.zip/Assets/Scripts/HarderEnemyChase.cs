using UnityEngine;

public class HarderEnemyChase : MonoBehaviour
{
    public float speed = 5.0f;
    public int maxHealth = 6;
    private int currentHealth;
    private Transform playerTransform;
    public int attackDamage = 1;
    public float attackCooldown = 1.5f;
    private float lastAttackTime = 0f;

    void Start()
    {
        currentHealth = maxHealth;
        GameObject player = GameObject.Find("player");
        if (player != null) playerTransform = player.transform;
    }

    void Update()
    {
        if (playerTransform != null)
        {
            Vector3 direction = (playerTransform.position - transform.position).normalized;
            transform.position += direction * speed * Time.deltaTime;
        }
    }

    void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.name == "player" && Time.time > lastAttackTime + attackCooldown)
        {
            // Implement player health reduction here
            Debug.Log("Enemy attacks player for " + attackDamage + " damage.");
            lastAttackTime = Time.time;
        }
    }

    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth <= 0) Destroy(gameObject);
    }
}