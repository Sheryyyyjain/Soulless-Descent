using UnityEngine;
using UnityEngine.SceneManagement;

public class AutoSceneChange : MonoBehaviour
{
    public string sceneName = "NextScene";   // Replace with your target scene's name

    void Start()
    {
        Invoke("ChangeScene", 15f);
    }

    void ChangeScene()
    {
        SceneManager.LoadScene(sceneName);
    }
}