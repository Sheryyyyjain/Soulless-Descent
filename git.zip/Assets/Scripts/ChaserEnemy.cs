using UnityEngine;

public class ChaserEnemy : MonoBehaviour
{
    [Header("Settings")]
    public float speed = 3f;               // Movement speed
    public float detectionRange = 10f;     // How far the enemy can see the player
    public float stopDistance = 1f;        // Distance to stop before hitting player

    private Transform player;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        // Find player
        GameObject playerObj = GameObject.FindGameObjectWithTag("player");
        if (playerObj != null)
            player = playerObj.transform;
        else
            Debug.LogWarning("ChaserEnemy: Player not found! Make sure the player has tag 'Player'.");
    }

    void Update()
    {
        if (player == null) return;

        float distance = Vector2.Distance(transform.position, player.position);

        // Only move if within detection range and not too close
        if (distance <= detectionRange && distance > stopDistance)
        {
            Vector2 direction = (player.position - transform.position).normalized;
            rb.linearVelocity = new Vector2(direction.x * speed, rb.linearVelocity.y);

            // Flip enemy to face player
            Vector3 scale = transform.localScale;
            scale.x = direction.x > 0 ? Mathf.Abs(scale.x) : -Mathf.Abs(scale.x);
            transform.localScale = scale;
        }
        else
        {
            // Stop moving
            rb.linearVelocity = new Vector2(0, rb.linearVelocity.y);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Debug.Log("Player hit by Chaser Enemy!");
            // Add player damage logic here
        }
    }
}
