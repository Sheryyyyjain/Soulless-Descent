using UnityEngine;

public class BasicEnemy : MonoBehaviour
{
    public float speed = 3f; // Enemy movement speed

    void Update()
    {
        // Find the player every frame (avoids "player not defined")
        GameObject playerObj = GameObject.FindGameObjectWithTag("player");
        if (playerObj == null) return; // no player in scene

        // Move enemy toward player
        Vector2 direction = (playerObj.transform.position - transform.position).normalized;
        transform.position = Vector2.MoveTowards(transform.position, playerObj.transform.position, speed * Time.deltaTime);

        // Optional: flip enemy to face player
        Vector3 scale = transform.localScale;
        scale.x = direction.x > 0 ? Mathf.Abs(scale.x) : -Mathf.Abs(scale.x);
        transform.localScale = scale;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("player"))
        {
            Debug.Log("BasicEnemy touched the player!");
            // TODO: Add your damage logic here
        }
    }
}
