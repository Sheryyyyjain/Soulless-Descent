using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 5f;
    public float jumpForce = 7f;

    private Rigidbody2D rb;
    private bool isGrounded = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        // Move left/right
        float move = Input.GetAxisRaw("Horizontal"); // -1 left, 1 right
        rb.linearVelocity = new Vector2(move * speed, rb.linearVelocity.y);

        // Flip sprite
        if (move != 0)
        {
            Vector3 scale = transform.localScale;
            scale.x = move > 0 ? Mathf.Abs(scale.x) : -Mathf.Abs(scale.x);
            transform.localScale = scale;
        }

        // Jump
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Simple ground check
        if (collision.gameObject.CompareTag("Ground"))
            isGrounded = true;

        // Enemy contact
        if (collision.gameObject.CompareTag("enemy"))
        {
            Debug.Log("Player hit by enemy!");
            // TODO: Reduce player health here
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
            isGrounded = false;
    }
}
